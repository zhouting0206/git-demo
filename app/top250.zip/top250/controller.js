'use strict';
(function(angular){
	//创建模块
	var module=angular.module('movieCat.top250',['ngRoute'])

//  创建路由
	module.config(['$routeProvider',function($routeProvider){
		$routeProvider.when(
			'/top250',{
				templateUrl:'top250/view.html',
				controller:"top250Controller"
			}
		)
	}])
	module.controller('top250Controller',['$scope',function($scope){

	}])

})(angular)
